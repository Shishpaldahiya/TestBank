import LoginPage from "../PageObjects/LoginPage";

describe('',()=>{

const ln2=new LoginPage()
ln2.


})