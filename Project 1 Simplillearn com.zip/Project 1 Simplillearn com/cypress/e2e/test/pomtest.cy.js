import { describe } from "mocha";
import LoginPage from "../../PageObjects/LoginPage";

describe('',()=>{

    const loginPage=new LoginPage();
    


})